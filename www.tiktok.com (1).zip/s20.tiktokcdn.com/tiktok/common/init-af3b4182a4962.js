(function(a) {
    var d = document,
        w = window,
        u = "https://s20.tiktokcdn.com/tiktok/common/init.js?seed=AAC3_YSIAQAAXkP-q9EK_L7244HX0-FGWjgkmh4Ouih-Pmn1fiyv-bKt50KI&hTc6j8Njvn--z=q",
        v = "dALiuIVqS",
        i = "21693c8ab0c8459877f506cd5f01571e";
    var s = d.currentScript;
    addEventListener(v, function f(e) {
        e.stopImmediatePropagation();
        removeEventListener(v, f, !0);
        e.detail.init("A0an_4SIAQAASVtZ6MisBG0o15yPA-phSZ1rMjfkGLb9WZQq237RuLs64MJVAWuYLykJ-H0ewH9drDJd7j1drA==", "PcgjbNIz=us4fn07WwTr5V3eG1xHKRk8-OqQ6ha2B9oivCLmyZDtXApEMUldYFS_J", [], [446250566, 2108748700, 1933486120, 1245232609, 1931759306, 661759021, 57863948, 1761795020], document.currentScript && document.currentScript.nonce || "YhYyMw1FTP0dt+M0cJBQu7up", document.currentScript && document.currentScript.nonce || "YhYyMw1FTP0dt+M0cJBQu7up", [], a)
    }, !0);
    var o = s && s.nonce ? s.nonce : "";
    try {
        s && s.parentNode.removeChild(s)
    } catch (e) {} {
        var n = d.createElement("script");
        n.id = i;
        n.src = u;
        n.async = !0;
        n.nonce = o;
        d.head.appendChild(n)
    }
}(typeof arguments === "undefined" ? void 0 : arguments))